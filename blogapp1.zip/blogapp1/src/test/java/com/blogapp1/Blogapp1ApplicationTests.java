package com.blogapp1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Blogapp1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
